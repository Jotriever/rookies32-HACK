import { useCallback, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import type { SetURLSearchParams } from 'react-router-dom';
import { Column, Select, StackedCell, StatusPill } from '@/shared/ui';
import { FundsTabLayout } from './FundsTabLayout';
import { formatCurrency, formatDateTime, maskName, memberRef } from '@/shared/lib/format';
import { storePaymentStatusMeta, type StorePaymentStatus } from '@/shared/lib/wallet';
import { DEFAULT_PAGE_SIZE } from '@/shared/lib/constants';
import { fetchStorePayments, fundKeys } from '../api';
import type { StorePayment } from '../types';

const STATUS_FILTERS: { value: StorePaymentStatus | 'ALL'; label: string }[] = [
  { value: 'ALL', label: '결제 상태: 전체' },
  { value: 'PAID', label: '결제 완료' },
  { value: 'CANCELLED', label: '취소' },
];

interface StorePaymentsTabProps {
  keyword: string;
  status: StorePaymentStatus | 'ALL';
  childId?: number;
  page: number;
  patchParams: (patch: Record<string, string | null>, resetPage?: boolean) => void;
  setSearchParams: SetURLSearchParams;
}

/**
 * 자녀의 매장 QR 결제 내역 (GET /admin/payments).
 * 조회 전용이다. 강제 환불은 사용하지 않는다(충전 취소는 "충전·용돈" 탭에 있다).
 */
export function StorePaymentsTab({
  keyword,
  status,
  childId,
  page,
  patchParams,
  setSearchParams,
}: StorePaymentsTabProps) {
  const params = useMemo(
    () => ({ keyword, status, childId, page, size: DEFAULT_PAGE_SIZE }),
    [keyword, status, childId, page],
  );

  const { data, isPending, isError } = useQuery({
    queryKey: fundKeys.payments(params),
    queryFn: () => fetchStorePayments(params),
  });

  const handleSearch = useCallback((value: string) => patchParams({ keyword: value }), [patchParams]);

  const columns: Column<StorePayment>[] = [
    {
      key: 'child',
      header: '자녀 / 보호자',
      width: '24%',
      /*
       * 페어링된 보호자가 없으면 서버가 parentId·parentName 을 null 로 준다.
       * 그대로 찍으면 "회원 #null" 이라는 없는 회원이 생기므로 문구로 대체한다.
       */
      render: (row) => (
        <StackedCell
          primary={`${maskName(row.childName ?? '')} (${memberRef(row.childId, '자녀')})`}
          secondary={
            row.parentId != null
              ? `보호자 ${maskName(row.parentName ?? '')} (${memberRef(row.parentId)})`
              : '보호자 미연결'
          }
        />
      ),
    },
    { key: 'merchant', header: '매장', render: (row) => row.storeName },
    {
      key: 'amount',
      header: '결제 금액',
      align: 'right',
      numeric: true,
      width: '128px',
      render: (row) => <span className="funds__amount">{formatCurrency(row.amount)}</span>,
    },
    {
      key: 'balanceAfter',
      header: '결제 후 잔액',
      align: 'right',
      numeric: true,
      width: '136px',
      render: (row) => <span className="muted">{formatCurrency(row.balanceAfter)}</span>,
    },
    {
      key: 'status',
      header: '상태',
      width: '104px',
      render: (row) => (
        <StatusPill tone={storePaymentStatusMeta(row.status).tone}>
          {storePaymentStatusMeta(row.status).label}
        </StatusPill>
      ),
    },
    {
      key: 'paidAt',
      header: '결제 일시',
      numeric: true,
      width: '168px',
      render: (row) => formatDateTime(row.paidAt),
    },
  ];

  return (
    <FundsTabLayout
      /* 서버 keyword 는 자녀·보호자 실명만 본다. 매장명은 별도 파라미터라 여기서 못 찾는다. */
      searchPlaceholder="자녀명 · 보호자명 검색"
      searchLabel="매장 결제 검색"
      keyword={keyword}
      onSearch={handleSearch}
      filter={
        <Select
          value={status}
          onChange={(e) => patchParams({ status: e.target.value === 'ALL' ? null : e.target.value })}
          aria-label="결제 상태 필터"
        >
          {STATUS_FILTERS.map((f) => (
            <option key={f.value} value={f.value}>
              {f.label}
            </option>
          ))}
        </Select>
      }
      caption="매장 결제 내역"
      columns={columns}
      data={data}
      rowKey={(r) => r.id}
      loading={isPending}
      error={isError}
      entityName="결제 내역"
      tab="payments"
      onResetFilters={(tab) => setSearchParams(new URLSearchParams({ tab }))}
      onPageChange={(next) => patchParams({ page: String(next) }, false)}
    />
  );
}
