import type { IconName } from '@/shared/ui';
import type { Role } from './types';

/* --------------------------------------------------------------- 역할 ---- */

export const ROLE_LABEL: Record<Role, string> = {
  SUPER_ADMIN: '슈퍼 관리자',
  GENERAL_ADMIN: '일반 관리자',
  COMMUNITY_ADMIN: '커뮤니티 관리자',
  INQUIRY_ADMIN: '문의 관리자',
};

/** 관리자 계정 관리 화면의 역할 선택지. */
export const ROLE_OPTIONS: { value: Role; label: string; hint: string }[] = [
  { value: 'SUPER_ADMIN', label: '슈퍼 관리자', hint: '전체 기능' },
  { value: 'GENERAL_ADMIN', label: '일반 관리자', hint: '회원·결제·문의' },
  { value: 'COMMUNITY_ADMIN', label: '커뮤니티 관리자', hint: '게시글·밴' },
  { value: 'INQUIRY_ADMIN', label: '문의 관리자', hint: '1:1 문의' },
];

/* --------------------------------------------------------- 사이드바 ---- */

export type NavIconName =
  | 'dashboard'
  | 'members'
  | 'payments'
  | 'notices'
  | 'inquiries'
  | 'community'
  | 'harmful'
  | 'audit'
  | 'admins';

export interface NavItem {
  to: string;
  label: string;
  icon: NavIconName;
  /** 접근 가능한 역할. 비어 있으면 인증된 모든 관리자. */
  roles?: Role[];
}

/**
 * 사이드바 9개. 권한은 API 명세 5장의 엔드포인트별 인증 요구사항을 따른다.
 *
 * 핸드오프 문서의 확정 결정에 따라 "리포트" 메뉴는 두지 않는다.
 * (CSV 리포트는 회원 상세의 모달에서 GET /admin/reports/*.csv 를 호출)
 *
 * 1:1 문의는 명세 5.4 기준 SUPER_ADMIN · INQUIRY_ADMIN 만 접근할 수 있다
 * (GENERAL_ADMIN 은 403).
 */
/** 메뉴 아이콘 이름 → 실제 아이콘 자산. 사이드바와 홈 화면이 함께 쓴다. */
export const NAV_ICON: Record<NavIconName, IconName> = {
  dashboard: 'nav-dashboard',
  members: 'nav-members',
  payments: 'nav-payments',
  notices: 'nav-notices',
  inquiries: 'nav-inquiries',
  community: 'nav-community',
  harmful: 'nav-harmful',
  audit: 'nav-audit',
  admins: 'nav-admins',
};

export const NAV_ITEMS: NavItem[] = [
  { to: '/', label: '홈 화면', icon: 'dashboard' },
  /*
   * 회원 관리는 SUPER_ADMIN 전용이다. 서버가 `/api/admin/members/**` 전체를
   * (조회까지) SUPER_ADMIN 으로 막고 있어, GENERAL_ADMIN 에게 메뉴를 열어 두면
   * 들어가는 순간 목록·상세가 전부 403 이라 빈 화면만 본다.
   */
  { to: '/members', label: '회원 관리', icon: 'members', roles: ['SUPER_ADMIN'] },
  /* 자금·결제도 SUPER_ADMIN 전용(서버가 GENERAL_ADMIN 을 403 으로 차단). */
  { to: '/payments', label: '자금·결제 관리', icon: 'payments', roles: ['SUPER_ADMIN'] },
  {
    to: '/notices',
    label: '공지 관리',
    icon: 'notices',
    /* 공지는 관리자 4종 전체 조회·관리 허용(백엔드 권한표 반영). */
    roles: ['SUPER_ADMIN', 'GENERAL_ADMIN', 'COMMUNITY_ADMIN', 'INQUIRY_ADMIN'],
  },
  {
    to: '/inquiries',
    label: '1:1 문의',
    icon: 'inquiries',
    roles: ['SUPER_ADMIN', 'INQUIRY_ADMIN'],
  },
  {
    to: '/community',
    label: '커뮤니티 관리',
    icon: 'community',
    /*
     * 서버는 `/api/admin/community/**` 를 **조회까지** SUPER_ADMIN·COMMUNITY_ADMIN
     * 으로만 연다. 명세 5.5 에는 GENERAL_ADMIN 도 목록을 볼 수 있다고 적혀 있었으나
     * 실제 시큐리티 체인이 그렇지 않아, 열어 두면 목록부터 403 이 난다.
     */
    roles: ['SUPER_ADMIN', 'COMMUNITY_ADMIN'],
  },
  {
    to: '/harmful-keywords',
    label: '유해사이트 관리',
    icon: 'harmful',
    /* 유해사이트는 관리자 4종 전체 허용(백엔드 권한표 반영). */
    roles: ['SUPER_ADMIN', 'GENERAL_ADMIN', 'COMMUNITY_ADMIN', 'INQUIRY_ADMIN'],
  },
  { to: '/audit-logs', label: '감사 로그', icon: 'audit', roles: ['SUPER_ADMIN'] },
  { to: '/admins', label: '관리자 계정 관리', icon: 'admins', roles: ['SUPER_ADMIN'] },
];

/* ------------------------------------------------- 상단 가로 내비 그룹 ---- */

export interface NavGroup {
  key: string;
  label: string;
  /** 이 그룹에 속한 NAV_ITEMS 의 경로. 이 순서대로 드롭다운에 나열된다. */
  paths: string[];
}

/**
 * CleanPay 식 이중 내비의 상단 대분류. 항목이 1개면 링크, 2개 이상이면 드롭다운.
 * 권한으로 항목이 전부 걸러지면 그룹 자체를 숨긴다(Topbar 에서 처리).
 */
export const NAV_GROUPS: NavGroup[] = [
  { key: 'home', label: '홈', paths: ['/'] },
  { key: 'members', label: '회원·자금', paths: ['/members', '/payments'] },
  { key: 'content', label: '콘텐츠', paths: ['/notices', '/inquiries', '/community'] },
  { key: 'safety', label: '안전', paths: ['/harmful-keywords'] },
  { key: 'system', label: '시스템', paths: ['/audit-logs', '/admins'] },
];

/* ----------------------------------------------------------- 페이징 ---- */

/** 명세 3.5 의 기본값은 20 이나, 화면 밀도상 목록은 10건으로 끊는다. */
export const DEFAULT_PAGE_SIZE = 10;

/** 목록에서 고를 수 있는 페이지당 표시 건수. */
export const PAGE_SIZE_OPTIONS = [10, 20, 50] as const;

/* ------------------------------------------------------------- 저장소 ---- */

export const AUTH_STORAGE_KEY = 'careguard.auth';
export const THEME_STORAGE_KEY = 'careguard.theme';
